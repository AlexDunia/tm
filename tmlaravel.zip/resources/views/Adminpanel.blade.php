<head>

    <link
        rel="stylesheet"
        href="\css\admin.css"/>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/solid.css">
        <script src="https://kit.fontawesome.com/9ff47ec0f8.js" crossorigin="anonymous"> </script>
</head>
<body>
    <h1> Hello Admin </h1>
{{-- @foreach($welcome as $onewelcome) --}}
<div id="slideshow-container">
    @foreach($welcome->reverse()->take(3) as $index => $onewelcome)
        <div class="background-slideshow" style="background-image: url('{{asset('storage/' . $onewelcome->heroimage)}}'); animation-delay: {{$index * 3}}s;">
            <a href="/events/{{$onewelcome['id']}}"> {{$onewelcome['herolink']}} </a>
        </div>
    </div>
<br/>
@endforeach
<div class="slidediv">
<div class="slideshow-arrow left" onclick="prevSlide()">&#8249;</div>
<div class="slideshow-arrow right" onclick="nextSlide()">&#8250;</div>
</div>

<div class="afterhero">
@foreach($welcome as $onewelcome)
<a href="/events/{{$onewelcome['id']}}"> {{$onewelcome['name']}} </a>
<img  src="{{asset('storage/' . $onewelcome->image)}}">
<br/>
@endforeach
</div>
<script>
     const slides = document.querySelectorAll('.background-slideshow');
        let currentSlide = 0;

        function showSlide(slideIndex) {
            slides[currentSlide].style.opacity = '0';
            slides[slideIndex].style.opacity = '1';
            currentSlide = slideIndex;
        }

        function nextSlide() {
            const nextIndex = (currentSlide + 1) % slides.length;
            showSlide(nextIndex);
        }

        function prevSlide() {
            const prevIndex = (currentSlide - 1 + slides.length) % slides.length;
            showSlide(prevIndex);
        }

        setInterval(nextSlide, 5000); // Switch slide every 3 seconds
</script>