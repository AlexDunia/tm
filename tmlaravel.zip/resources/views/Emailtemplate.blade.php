<h1> Hello, you requested to change your password </h1>
 <a href="{{route("rp", $token)}}"> Click here to Reset password </a>