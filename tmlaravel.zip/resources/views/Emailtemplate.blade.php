<h1> Hello, you requested to change your password </h1>
{{-- <a href="{{route("rp", $token)}}"> Reset password </a> --}}