{{-- @foreach($welcome as $Onedata)
<p> {{$Onedata['name']}} </p>
@endforeach --}}

{{-- <h1> {{$heading}} </h1>
@foreach($welcome as $onewelcome)
<a href="/events/{{$onewelcome['id']}}"> {{$onewelcome['name']}} </a>
<br/>
@endforeach --}}


{{-- <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<script type="module" src="{{ mix('resources/js/app.js') }}"></script>
</head>
<body> --}}
	{{-- @if (Auth::guard('admin')) { --}}
    {{-- @auth --}}
		// Admin authentication successful
		// Your logic here
		<header></header>
    <h1> {{$heading}} </h1>
    <p>Cart Item Count: {{ $cartItemCount }}</p>
    {{-- Add the following line to display the authenticated user's information --}}
    {{-- <pre>{{ dd(auth()->user()) }}</pre> --}}

    @foreach($welcome as $onewelcome)
    <img  src="{{asset('storage/' . $onewelcome->heroimage)}}">
    <a href="/events/{{$onewelcome['id']}}"> {{$onewelcome['herolink']}} </a>
    {{-- <button> Hit me </button> --}}
    <br/>
@endforeach

{{-- @else --}}
    @foreach($welcome as $onewelcome)
        <a href="/events/{{$onewelcome['id']}}"> {{$onewelcome['name']}} </a>
        {{-- <button> Hit me </button> --}}
        <form action="{{url('/addtocart', $onewelcome->id)}}" method="POST">
            @csrf <!-- Add this line to include the CSRF token -->
            <input type="submit" value="Add to cart!"/>
        </form>
        <br/>
    @endforeach

    <div id="app"></div>
{{-- @endauth --}}


{{-- <div id="app-a">
    <Component-a></Component-a>
</div> --}}

