<h1> {{$listonee['name']}} </h1>
<h1> {{$listonee['location']}} </h1>
<a href="/event/{{$listonee['id']}}/ticket"> Edit </a>
@verbatim
    <div id="apk"></div>
@endverbatim
