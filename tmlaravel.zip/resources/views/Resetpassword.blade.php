<h1> Reset your password here </h1>

<form method="post" class="fstyle" action="{{route('rpp')}}" enctype="multipart/form-data">

    {{ csrf_field() }}

    <div>
        <input id="email" class="nlstyle" type="email" name="email" placeholder="Your Email">
        @error('email')
        <p class="inputeerror" style="color:rgb(252, 80, 80)"> {{$message}} </p>
        @enderror
    </div>

    <div>
        <input id="email" class="nlstyle" type="email" name="email" placeholder="Confirm email">
        @error('email')
        <p class="inputeerror" style="color:rgb(252, 80, 80)"> {{$message}} </p>
        @enderror
    </div>

        <button class="newsbtn" type="submit"> Reset Password </button>
          </div>
        </form>