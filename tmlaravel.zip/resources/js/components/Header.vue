<template>
    <div>
        <h1>Hello from Vue</h1>
        <!-- <button @click="addToCart">Another fucking button </button> -->
    </div>
</template>

 <script>
        export default {
            mounted() {
                console.log('Component mounted.')
            }
        }
    </script>


