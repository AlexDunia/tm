<head>

    <link
        rel="stylesheet"
        href="\css\listone.css"/>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/solid.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="//unpkg.com/alpinejs" defer></script>
        <script src="https://kit.fontawesome.com/9ff47ec0f8.js" crossorigin="anonymous"> </script>
</head>
<body>

    <?php echo $__env->make('_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="circularr" style="background-image: url('<?php echo e(asset('images/crowd.jpg')); ?>');">

    <?php if(session()->Has("message")): ?>{
        <div class="qerror" x-data="{show: true}" x-init="setTimeout(() => show = false, 3000)" x-show="show">
            <p> AT LEAST ONE QUANTITY MUST BE ADDED BEFORE PROCEEDING! </p>
            </div>
    }
    <?php endif; ?>

    <div class="blurcontainer">

    <div class="bcflex">

    <div class="bctext">
    <p class="cat"> Category: Music / Show / Concert </p>
    <h1> <?php echo e($listonee['name']); ?> </h1>
    <p class="infoticket"> <?php echo e($listonee['description']); ?> </p>
    <div id="countdown"></div>
    <p class="infodate"> <i class="fa-solid fa-calendar-day"> </i> <?php echo e($listonee['location']); ?> </p>
    </div>

    <div class="bcimg">
        <img  src="<?php echo e(asset('storage/' . $listonee->image)); ?>">
    </div>

    </div>

    </div>
    

    
<br/>
<br/>
<br/>

<form action="<?php echo e(url('/addtocart')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <table class="custom-table">
        <tr>
            <th> Pricing </th>
            <th> Quantity </th>
        </tr>
        <?php
            $tableNames = ['startingprice', 'earlybirds', 'tableone', 'tabletwo', 'tablethree', 'tablefour', 'tablefive', 'tablesix', 'tableseven', 'tableeight'];
        ?>
        <?php $__currentLoopData = $tableNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tableName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($listonee[$tableName])): ?>
                <tr>
                    <td class="pricedata">
                        <?php echo e(explode('.', trim($listonee[$tableName]))[0]); ?>

                        <input type="hidden" name="product_ids[]" value="<?php echo e($listonee->id); ?>">
                        <input type="hidden" name="table_names[]" value="<?php echo e(explode('.', $listonee[$tableName])[0]); ?> ">
                    </td>
                    <td class="pricequantity">
                        <?php if(strpos($listonee[$tableName], '.') !== false): ?>
                            
                            
                            <h3 class="soldout">  <?php echo e(explode('.', $listonee[$tableName])[1]); ?> </h3>
                        <?php else: ?>
                            
                            <select name="quantities[]" class="quantity-select" onchange="updateQuantities(this)">
                                <?php for($i = 0; $i <= 50; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>

                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <input class="checkoutt" type="submit" value="Add Selected Items to Cart">
</form>



<div class="cdbg">

<div class="cdflex">

<div class="dtgflex">

<div class="nodtg">
    <h1 id="days">0</h1>
</div>

<div class="dtg">
 <h2> Days </h2>
 <h2> To Go </h2>
</div>

</div>

<!-- Main -->

<div class="maincdtextflex">



<div class="maincdtext">
    <h1 id="hours">0</h1>
<h3> Hours </h3>
</div>

<div class="maincdtext">
    <h1 id="minutes">0</h1>
<h3> Minutes </h3>
</div>

<div class="maincdtext">
    <h1 id="seconds">0</h1>
<h3> Minutes </h3>
</div>

</div>

</div>

</div>

<br/>
<br/>
<br/>
<br/>



<div class="eventinfo">
<h1> Event information </h1>
<hr/>

<div class="eventinfoflex">

<div class="eventinfotext">
    <h3 class="pinktext"> Start Date </h3>
    <h3 class="ntext"> 19/20/21 </h3>
</div>

<div class="eventinfotext">
    <h3 class="pinktext"> Time </h3>
    <h3 class="ntext"> 19/20/21 </h3>
</div>

<div class="eventinfotext">
    <h3 class="pinktext"> End Date  </h3>
    <h3 class="ntext"> 19/20/21 </h3>
</div>

<div class="eventinfotext">
    <h3 class="pinktext"> Category  </h3>
    <h3 class="ntext"> 19/20/21 </h3>
</div>



</div>

<br/>
<br/>

</div>
<br/>
<br/>
<br/>
<br/>
 
</div>



</body>

<script>

function updateQuantities(selectedQuantityElement) {
        // Get the selected quantity value
        var selectedQuantity = selectedQuantityElement.value;

        // Get all quantity select elements
        var quantitySelects = document.querySelectorAll('.quantity-select');

        // Loop through all quantity select elements
        quantitySelects.forEach(function (quantitySelect) {
            // Set the value to zero for all other elements
            if (quantitySelect !== selectedQuantityElement) {
                quantitySelect.value = 0;
            }
        });
    }

// window.onload = function () {
//     location.reload();
//   };




    // Get the target date and time from the Blade template
    const targetDate = new Date("<?php echo e($listonee['date']); ?>");

    // Update the countdown every second
    const daysElement = document.getElementById("days");
    const hoursElement = document.getElementById("hours");
    const minutesElement = document.getElementById("minutes");
    const secondsElement = document.getElementById("seconds");

    const countdownInterval = setInterval(() => {
        const currentDate = new Date();
        const timeRemaining = targetDate - currentDate;

        if (timeRemaining > 0 ) {
            const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
            const hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);

            daysElement.innerText = days;
            hoursElement.innerText = hours;
            minutesElement.innerText = minutes;
            secondsElement.innerText = seconds;
        } else if(timeRemaining < 0){
            daysElement.innerText = "0";
            hoursElement.innerText = "0";
            minutesElement.innerText = "0";
            clearInterval(countdownInterval);
        } else {
            daysElement.innerText = "0";
            hoursElement.innerText = "0";
            minutesElement.innerText = "0";
            clearInterval(countdownInterval);
        }
        // else {
        //     countdownElement.innerHTML = "Countdown expired";
        //     clearInterval(countdownInterval);
        // }
    }, 1000); // Update every second
</script>

<?php /**PATH C:\Users\HP\tmlaravel\resources\views/listone.blade.php ENDPATH**/ ?>