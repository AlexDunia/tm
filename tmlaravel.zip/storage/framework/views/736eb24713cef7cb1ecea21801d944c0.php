<h1> <?php echo e($listonee['name']); ?> </h1>
<h1> <?php echo e($listonee['location']); ?> </h1>
<a href="/event/<?php echo e($listonee['id']); ?>/ticket"> Edit </a>

    <div id="apk"></div>

<?php /**PATH C:\Users\HP\tmlaravel\resources\views/listone.blade.php ENDPATH**/ ?>