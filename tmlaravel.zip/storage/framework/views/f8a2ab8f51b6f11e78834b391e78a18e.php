<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name= "viewport" content="width=device-width, initial-scale=1">
<title> Sign up </title>
<link rel="stylesheet" href="css/style.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="assets/img/favicon.ico" rel="icon">

</head>
<style>

    body{
        padding:0;
        margin:0;
        color: white;
    }

    /* .tyaround{
        width:80%;
        margin:auto;
        margin-top:100px;
    }

    .tybg{
        color: #a0aec0;
        padding-bottom:150px;
        padding-top:40px;
    }

    .tybg p {
        font-size:15px;
        color: #a0aec0;
        margin-bottom:15px;
    }

    .tybg h1{
        font-size:35px;
        margin:auto;
        text-align:center;
        margin-bottom:20px;
    }

    .tybg a{
        color: #C04888;
        font-size:15px;
        margin-top:5px;
    }

    .pty{
        color: #a0aec0;
    } */

    .tyaround {
        width: 85%;
        /* max-width: 400px;  */
        margin: auto;
    }


    .tyaround{
        margin:auto;
        align-items: center;
    }

    .tyaround h1{
        /* text-align:center; */
        font-size:40px;
        margin-top:30px;
        margin-bottom:60px;
    }

    .tyaround form label {
        padding-top:300px;
        margin-top:300px;
        font-size: 20px;
    }

    form input,
    form textarea {
        width: 100%;
        padding: 20px;
        background: rgba(37, 36, 50, .8);
        border: none;
        margin-top: 20px;
        box-sizing: border-box; /* Add this property to include padding and border in the width calculation */
    }

    .btncontact {
        min-width: 100%;
        padding: 20px;
        background-color: #C04888;
        color: white;
        font-size: 20px;
        font-weight: 600;
        border: none;
        margin-top: 20px;
    }

    .lab{
        margin-top:20px;
    }

    @media (max-width: 700px) {

        .tyaround h1{
        font-size:30px;
    }


        .tybg{
        background: rgba(37, 36, 50, .8);
        color: #a0aec0;
        padding-bottom:50px;
        padding-top:40px;
        padding-left:10px;
    }

    .tybg p {
        font-size:14px;
        color: #a0aec0;
        margin-bottom:10px;
    }


    .tybg h1{
        font-size:23px;
    }
    }

</style>
<body>
    <?php echo $__env->make('_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br/>
    <br/>

    
    
        <div class="tyaround">
        <h1> Login to your account. </h1>
        <form method="post" class="fstyle" action="/authenticated">

        <?php echo csrf_field(); ?>
        <label for="email"> Email: </label>
        <input id="email" class="nlstyle" type="email" name="email" placeholder="Your Email">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="inputeerror" style="color:rgb(252, 80, 80)"> <?php echo e($message); ?> </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </br>

        <br/>
        <br/>
        <label for="password">Password:</label>
        <input id="email" class="nlstyle" type="password" name="password" placeholder="Your Password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="inputeerror" style="color:rgb(252, 80, 80)"> <?php echo e($message); ?> </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <br/>
        <br/>
        <br/>

        <a> Forgot Password </a>

          <div>
        <button class="btncontact" type="submit"> Log In </button>
          </div>


    </form>

    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>



</body>
</html>

<?php /**PATH C:\Users\HP\tmlaravel\resources\views/Login.blade.php ENDPATH**/ ?>