<!DOCTYPE html>
<html>
<head>
    <title>Login Device Info</title>
</head>
<body style="font-family: 'Montserrat', sans-serif; -webkit-font-smoothing: antialiased;">

    <div style="width: 80%; margin: auto;">
        <a href="https://www.tixdemand.com/" target="_blank">
            <img src="https://fextellar.com/images/ft.png" alt="tixdemand" style="display: block; margin: 0 auto; margin-bottom: 50px;">
        </a>
        <h2 style="color: #333">Hello <?php echo e($firstname); ?></h2>
        <p style="color: #333;">We've just noticed a new login device on your account</p>
        <br>
        <br>
        <h3 style="color: #f746a5;">Login device info</h3>
        <br>
        <p style="margin-top: 30px; margin-bottom: 30px; color: #333;">IP Address: <?php echo e($locationData->ip); ?></p>
        <hr>
        <p style="margin-top: 30px; margin-bottom: 30px; color: #333;">Country: <?php echo e($locationData->countryName); ?></p>
        <hr>
        <p style="margin-top: 30px; margin-bottom: 30px; color: #333;">Country Code: <?php echo e($locationData->countryCode); ?></p>
        <hr>
        <p style="margin-top: 30px; margin-bottom: 30px; color: #333;">Region: <?php echo e($locationData->regionCode); ?></p>
        <hr>
        <p style="line-height: 1.7em; color: #333;">If you did not initiate this, we recommend you  <a href="https://www.youtube.com/" target="_blank" style="color: #f746a5; font-weight: 700;">  click here to reset your password  </a>  immediately to secure your account. You can also reach out to us for assistance.</p>
    </div>

    <!-- You can customize the email content and styling as per your requirements -->
</body>
</html>
<?php /**PATH C:\Users\HP\tmlaravel\resources\views/logindeviceinfo.blade.php ENDPATH**/ ?>