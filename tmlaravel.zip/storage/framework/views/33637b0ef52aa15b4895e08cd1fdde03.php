





	
    
		// Admin authentication successful
		// Your logic here
		<header></header>
    <h1> <?php echo e($heading); ?> </h1>
    <p>Cart Item Count: <?php echo e($cartItemCount); ?></p>
    
    

    <?php $__currentLoopData = $welcome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onewelcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img  src="<?php echo e(asset('storage/' . $onewelcome->heroimage)); ?>">
    <a href="/events/<?php echo e($onewelcome['id']); ?>"> <?php echo e($onewelcome['herolink']); ?> </a>
    
    <br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php $__currentLoopData = $welcome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onewelcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/events/<?php echo e($onewelcome['id']); ?>"> <?php echo e($onewelcome['name']); ?> </a>
        
        <form action="<?php echo e(url('/addtocart', $onewelcome->id)); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- Add this line to include the CSRF token -->
            <input type="submit" value="Add to cart!"/>
        </form>
        <br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div id="app"></div>





<?php /**PATH C:\Users\HP\tmlaravel\resources\views/welcome.blade.php ENDPATH**/ ?>