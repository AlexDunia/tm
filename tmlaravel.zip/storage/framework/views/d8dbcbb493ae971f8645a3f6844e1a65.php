<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

    <link
        rel="stylesheet"
        href="\css\admin.css"/>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/solid.css">
        <script src="https://kit.fontawesome.com/9ff47ec0f8.js" crossorigin="anonymous"> </script>
</head>
<body>

  <?php echo $__env->make('_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="snf">
  <h1> Results for <span class="pink" >  "<?php echo e($si); ?>" </span> </h1>
  <br/>
  <div class="t_grids">
    @cache('cache_key', 60)
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onewelcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<div class="one_e">
<ul>
<li class="mypimage">  <img  src="<?php echo e(asset('storage/' . $onewelcome->image)); ?>"> </li>
<li class="noe">   <?php echo e($onewelcome['name']); ?>  </li>
  <div class="toe"> <i class="fa-solid fa-location-dot"> </i> <?php echo e($onewelcome['location']); ?> </div>
  <div class="toe"> <i class="fa-solid fa-calendar-days"></i>  <?php echo e($onewelcome['date']); ?> </div>

 

 <div class="toe"> <i class="fa-solid fa-ticket"></i> Starting @5000 </div>

 <button class="b_t"> <a href="/events/<?php echo e($onewelcome['name']); ?>"> View Event </a>  </button>
</ul>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
@endcache
</div>

  </div>
  <br/>
<br/>
  <?php echo $__env->make('_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body><?php /**PATH C:\Users\HP\tmlaravel\resources\views/Search.blade.php ENDPATH**/ ?>