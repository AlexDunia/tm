<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

    <link
        rel="stylesheet"
        href="\css\admin.css"/>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/solid.css">
        <script src="https://kit.fontawesome.com/9ff47ec0f8.js" crossorigin="anonymous"> </script>
</head>
<body>

  <?php echo $__env->make('_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <div class="circularbgg">

       
       <div class="view">
      <div class="latest"> <h1> Trending in <span class="pink"> <?php echo e($category); ?> </span>  </h1> </div>


        <div class="t_grids">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onewelcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
      <div class="one_e">
      <ul>
      <li class="mypimage">  <img  src="<?php echo e(asset('storage/' . $onewelcome->image)); ?>"> </li>
        <li class="noe">   <?php echo e($onewelcome['name']); ?>  </li>
          <div class="toe"> <i class="fa-solid fa-location-dot"> </i> <?php echo e($onewelcome['location']); ?> </div>
          <div class="toe"> <i class="fa-solid fa-calendar-days"></i>  <?php echo e($onewelcome['date']); ?> </div>

         

         <div class="toe"> <i class="fa-solid fa-ticket"></i> Starting @5000 </div>

         <button class="b_t"> <a href="/events/<?php echo e($onewelcome['name']); ?>"> View Event </a>  </button>
        </ul>
      </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

     </div>

     </div>

     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     <br/>
     



       <?php echo $__env->make('_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    

  </div>
</div>

  

  <br/>
  <br/>
  <br/>
  <br/>
  <br/>
  <br/>


</body>
<script>

</script>









	
    

		


        

    

    

    







<?php /**PATH C:\Users\HP\tmlaravel\resources\views/Filter.blade.php ENDPATH**/ ?>