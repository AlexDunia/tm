<head>

    <link
        rel="stylesheet"
        href="\css\checkout.css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/solid.css">
        <script src="https://kit.fontawesome.com/9ff47ec0f8.js" crossorigin="anonymous"> </script>
</head>





<body>



    <?php if(auth()->guard()->check()): ?>

    <?php
    // Where A stands for authenticated User
    $atotalPrice = 0; // Initialize the total price variable
    ?>

    
    <?php
    // where a stands for authenticated user.
    $atotalPrice += $mycart->ctotalprice;
    ?>

     <div class="checkoutimage">
     <img  width="250px" src="<?php echo e(asset('storage/' . $mycart->cdescription)); ?>">
     </div>

     <div class="checkoutname">
      <h1> <?php echo e($mycart->cname); ?> </h1>
     </div>

    <div class="ft">

    <div class="form">
        <div class="formhead">
            <h3> Buyer Information. </h3>
        </div>
            <form id="paymentForm" class="coformbg">
                <div class="form-group">
                  <label for="email">Email Address</label>
                  <input type="email" id="email-address" required />
                </div>
                <div class="form-group">
                  
                  <input type="hidden" id="amount"  value="<?php echo e($atotalPrice); ?>" required />
                </div>
                <div class="form-group">
                  
                  <input type="hidden" id="cn"  value="<?php echo e($mycart->cname); ?>" required />
                </div>
                <div class="form-group">
                  
                  <input type="hidden" id="cq"  value="<?php echo e($mycart->cquantity); ?>" required />
                </div>
                <div class="form-group">
                  
                  <input type="hidden" id="en"  value="<?php echo e($mycart->eventname); ?>" required />
                </div>

                <div class="form-group">
                  <label for="first-name">First Name</label>
                  <input type="text" id="first-name" />
                </div>
                <div class="form-group">
                  <label for="last-name">Last Name</label>
                  <input type="text" id="last-name" />
                </div>
                <div class="form-submit">
                  <button type="submit" onclick="payWithPaystack(event)" class="btncontact"> Pay </button>
                </div>
              </form>

        </div>



         

        <div class="tabledetailsbg">

            <div class="tabledetailsbghead">
            <h2> Ticket Information </h2>
            </div>

            

            <?php
            // Where A stands for authenticated User
            $atotalPrice = 0; // Initialize the total price variable
            ?>


        <div class="tabledetailsflex">


        <div class="tabledetails">
            
            <p> <?php echo e($mycart->cname); ?> X  <?php echo e($mycart->cquantity); ?> </p>
        </div>

        <div class="tabledetails">
            <p> <?php echo e($mycart->cprice); ?> </p>
        </div>
        <?php
        // where a stands for authenticated user.
        $atotalPrice += $mycart->ctotalprice;
        ?>

       
       </div>


       <div class="tabledetailsflex">

        <div class="tabledetails">
            <p> Total </p>
        </div>

        <div class="tabledetails">
             <p> <?php echo e($atotalPrice); ?> </p>
        </div>

       </div>



    </div>

     </div>

        <?php else: ?>


        <div class="checkoutimage">
          <img  width="250px" src="<?php echo e(asset('storage/' . $timage)); ?>">
          </div>

          <div class="checkoutname">
           <h1> <?php echo e($eventname); ?> </h1>
          </div>

        <div class="ft">

        <div class="form">
            <div class="formhead">
                <h3> Buyer Information </h3>
            </div>
        
            
             
                <form id="paymentForm" class="coformbg">
                    <div class="form-group">
                      <label for="email">Email Address</label>
                      <input type="email" id="email-address" required />
                    </div>
                    <div class="form-group">
                      
                      <input type="hidden" id="amount"  value="<?php echo e($totalprice); ?>" required />
                    </div>
                    <div class="form-group">
                      
                      <input type="hidden" id="cn"  value="<?php echo e($tname); ?>" required />
                    </div>
                    <div class="form-group">
                      
                      <input type="hidden" id="cq"  value="<?php echo e($tquantity); ?>" required />
                    </div>
                    <div class="form-group">
                      
                      <input type="hidden" id="en"  value="<?php echo e($eventname); ?>" required />
                    </div>

                    <div class="form-group">
                      <label for="first-name">First Name</label>
                      <input type="text" id="first-name" />
                    </div>
                    <div class="form-group">
                      <label for="last-name">Last Name</label>
                      <input type="text" id="last-name" />
                    </div>
                    <div class="form-submit">
                      <button type="submit" onclick="payWithPaystack(event)" class="btncontact"> Pay </button>
                    </div>
                  </form>

            </div>


    <div class="tabledetailsbg">

      <div class="tabledetailsbghead">
      <h2> Ticket Information </h2>
      </div>

  <div class="tabledetailsflex">

  <div class="tabledetails">
      
      <p> <?php echo e($tname); ?>  X  <?php echo e($tquantity); ?> </p>
  </div>

  <div class="tabledetails">
      <p> <?php echo e($tprice); ?> </p>
  </div>

 </div>

 <div class="tabledetailsflex">

  <div class="tabledetails">
      <p> Total </p>
  </div>

  <div class="tabledetails">
      <p> <?php echo e($totalprice); ?> </p>
  </div>




           



        </div>

         </div>


     </div>

     <?php endif; ?>

     <br/>
     <br/>
     <br/>
     <br/>
     <br/>

    

<script src="https://js.paystack.co/v1/inline.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
</body>

<script>
  const input = document.getElementById("cn").value;
  const words = input.split(' ');
  const fl = words.map(word => word[0]).filter(Boolean).join('');
  const fll = document.getElementById("en").value;
  const flsecond = fll.replace(/\s/g, '');
  const cr = fl + flsecond;
    const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);

function payWithPaystack(e) {
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: 'pk_test_a23671022344a4de4ca87e5b42f68b3f5d84bfd9', // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    "metadata": {
    "custom_fields": [
      {
        "display_name": "Event-name",
        "variable_name": "Event-name",
        "value": document.getElementById("cn").value,
      },
      {
        "display_name": "Quantity",
        "variable_name": "Quantity",
        "value": document.getElementById("cq").value,
      },
      {
        "display_name": "Eventname",
        "variable_name": "eventname",
        "value": fl,
      }
    ]
  },
    ref: 'TD' + cr +Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
  //   let message = 'Payment complete! Reference: ' + response.reference;
    let reference = response.reference
    fetch("<?php echo e(URL::to('verifypayment')); ?>/" + reference)
  .then(response => response.json())
  .then(data => {
      // console.log(data);
      window.location.href = "<?php echo e(URL::to('success')); ?>";
  })
  .catch(error => {
      // console.error("Error:", error);
  });


//       $.ajax({
//     type: "GET",
//     url: "<?php echo e(URL::to('verifypayment')); ?>/" + reference,
//     success: function(response) {
//         console.log(response);
//     }
// });

    //   console.log(reference);
    }
  });

  handler.openIframe();
}
</script><?php /**PATH C:\Users\HP\tmlaravel\resources\views/Checkout.blade.php ENDPATH**/ ?>