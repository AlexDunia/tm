<h1> Cart page </h1>
<?php $__currentLoopData = $mycart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onewelcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a> <?php echo e($onewelcome['cname']); ?> </a>
<a href="<?php echo e(url('/delete', $onewelcome->id)); ?>""> Delete me </a>
<br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\HP\tmlaravel\resources\views/Cartuser.blade.php ENDPATH**/ ?>