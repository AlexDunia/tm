<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MainadminController extends Controller
{
    //
    public function showadmin(){
        return view('Ad');
    }
}
