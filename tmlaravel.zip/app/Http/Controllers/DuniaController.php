<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DuniaController extends Controller
{
    //
    public function index(){
        return view('Adminpanel');
    }
}
