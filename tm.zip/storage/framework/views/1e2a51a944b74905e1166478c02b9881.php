<?php $__env->startSection('content'); ?>
<div class="main-container">
  <div class="content-wrapper">
    <div class="snf">
      <h1>Events > <span class="pink"><?php echo e($cat); ?></span></h1>
      <br/>
      <div class="t_grids">
        <?php $__currentLoopData = $cat_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onewelcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="one_e">
          <ul>
            <li class="mypimage"><img src="<?php echo e(str_starts_with($onewelcome->image, 'http') ? $onewelcome->image : asset('storage/' . $onewelcome->image)); ?>"></li>
            <li class="noe"><?php echo e($onewelcome->name); ?></li>
            <div class="toe"><i class="fa-solid fa-location-dot"></i> <?php echo e($onewelcome->location); ?></div>
            <div class="toe"><i class="fa-solid fa-calendar-days"></i> <?php echo e(date('n/j/Y', strtotime($onewelcome->date))); ?></div>
            <div class="toe"><i class="fa-solid fa-ticket"></i> Starting @5000</div>
            <button class="b_t"><a href="/events/<?php echo e($onewelcome->name); ?>">View Event</a></button>
          </ul>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\tm\resources\views\Filter.blade.php ENDPATH**/ ?>