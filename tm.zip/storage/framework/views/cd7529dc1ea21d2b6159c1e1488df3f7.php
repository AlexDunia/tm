<?php $__env->startSection('title', 'Session Expired'); ?>
<?php $__env->startSection('code', '419'); ?>
<?php $__env->startSection('icon', 'fas fa-clock'); ?>
<?php $__env->startSection('message', 'Session expired. Please log in again.'); ?>

<?php $__env->startSection('content'); ?>
<script>
    // Redirect after 3 seconds
    setTimeout(function() {
        window.location.href = '/login';
    }, 3000);
</script>
<p>Redirecting to login...</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('buttons'); ?>
<a href="/login" class="action-button">Log In Now</a>
<a href="/" class="action-button secondary">Return to Home</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\tm\resources\views\errors\419.blade.php ENDPATH**/ ?>