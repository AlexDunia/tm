<?php $__env->startSection('content'); ?>
<div class="main-container">
    <div class="content-wrapper">
        <div class="blurcontainer">
            <div class="bcflex">
                <div class="bctext">
                    <p class="cat">Category: <?php echo e($listonee['category']); ?></p>
                    <h1><?php echo e($listonee['name']); ?></h1>
                    <p class="infoticket"><?php echo e($listonee['description']); ?></p>
                    <div id="countdown"></div>
                    <p class="infodate"><i class="fa-solid fa-calendar-day"></i> <?php echo e($listonee['location']); ?></p>
                </div>

                <div class="bcimg">
                    <img src="<?php echo e(str_starts_with($listonee->image, 'http') ? $listonee->image : asset('storage/' . $listonee->image)); ?>">
                </div>
            </div>
        </div>

        <div class="cdbg">
            <div class="expired">
                <h1 id="days">Expired!</h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\tm\resources\views\expiredlistone.blade.php ENDPATH**/ ?>