<?php $__env->startComponent('mail::message'); ?>
# Reset Password Notification

You are receiving this email because we received a password reset request for your account.

<?php $__env->startComponent('mail::button', ['url' => $resetUrl]); ?>
Reset Password
<?php echo $__env->renderComponent(); ?>

This password reset link will expire in <?php echo e(config('auth.passwords.users.expire', 60)); ?> minutes.

If you did not request a password reset, no further action is required.

Regards,<br>
<?php echo e(config('app.name')); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\HP\tm\resources\views\emails\reset-password.blade.php ENDPATH**/ ?>