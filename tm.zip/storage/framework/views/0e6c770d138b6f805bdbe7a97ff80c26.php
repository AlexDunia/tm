<div class="footer-content">
    <hr/>
    <p> Copyright © kaka <?php echo e(date('Y')); ?>. All Rights Reserved. </p>
</div>

<script>
    document.getElementById('current-year').textContent = new Date().getFullYear();
</script>
<?php /**PATH C:\Users\HP\tm\resources\views\_footer.blade.php ENDPATH**/ ?>