<?php $__env->startSection('title', 'Authentication Required'); ?>
<?php $__env->startSection('code', '401'); ?>
<?php $__env->startSection('icon', 'fas fa-lock'); ?>
<?php $__env->startSection('message', 'You need to be logged in to access this page. Your session may have expired due to inactivity.'); ?>

<?php $__env->startSection('content'); ?>
<div class="steps">
    <h2 class="steps-title">Next Steps</h2>
    <div class="step">
        <div class="step-number">1</div>
        <div class="step-text">Click the login button below to sign back into your account</div>
    </div>
    <div class="step">
        <div class="step-number">2</div>
        <div class="step-text">After logging in, you'll be able to continue where you left off</div>
    </div>
    <div class="step">
        <div class="step-number">3</div>
        <div class="step-text">For security reasons, your session automatically expires after 15 minutes of inactivity</div>
    </div>
</div>

<div x-data="{ countdown: 5 }" x-init="setInterval(() => { if (countdown > 0) countdown--; if (countdown === 0) window.location.href = '/login'; }, 1000)">
    <p>Redirecting to login page in <span x-text="countdown" class="timer"></span> seconds</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('buttons'); ?>
<a href="/login" class="action-button">Log In Now</a>
<a href="/" class="action-button secondary">Return to Home</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\tm\resources\views\errors\401.blade.php ENDPATH**/ ?>