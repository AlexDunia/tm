<div class="footer-content">
    <hr/>
    <p> Copyright © kaka {{ date('Y') }}. All Rights Reserved. </p>
</div>

<script>
    document.getElementById('current-year').textContent = new Date().getFullYear();
</script>
