<!DOCTYPE html>
<html>
<head>
    <title> You have a new email </title>
</head>
<body>
    <p>Hello, Alex</p>
    <p>This is the message body of your email.</p>
</body>
</html>
