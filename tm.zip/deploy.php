<?php
/**
 * KakaWorld Production Deployment Script
 *
 * This script automates the process of deploying to production environments.
 * Run with: php deploy.php
 */

// Configuration
$startTime = microtime(true);
$appRoot = __DIR__;
$logFile = $appRoot . '/storage/logs/deployment-' . date('Y-m-d') . '.log';

// Make sure the log directory exists
if (!is_dir(dirname($logFile))) {
    mkdir(dirname($logFile), 0755, true);
}

/**
 * Log a message to the console and log file
 */
function log_message($message, $type = 'INFO') {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $type: $message";

    echo $logMessage . PHP_EOL;
    file_put_contents($logFile, $logMessage . PHP_EOL, FILE_APPEND);
}

/**
 * Run a shell command and log its output
 */
function run_command($command) {
    global $appRoot;

    log_message("Running: $command", 'CMD');

    $output = [];
    $returnVar = 0;

    chdir($appRoot);
    exec($command . ' 2>&1', $output, $returnVar);

    foreach ($output as $line) {
        log_message($line, 'OUTPUT');
    }

    if ($returnVar !== 0) {
        log_message("Command failed with exit code: $returnVar", 'ERROR');
        return false;
    }

    return true;
}

/**
 * Ensure the directory has correct permissions
 */
function set_permissions($directory, $fileMode = 0644, $dirMode = 0755) {
    log_message("Setting permissions for $directory", 'PERM');

    if (!is_dir($directory)) {
        log_message("Directory not found: $directory", 'ERROR');
        return false;
    }

    // Set directory permissions
    chmod($directory, $dirMode);

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        chmod($item, $item->isDir() ? $dirMode : $fileMode);
    }

    return true;
}

/**
 * Check if .env is correctly set for production
 */
function check_environment() {
    global $appRoot;

    log_message("Checking environment configuration", 'CHECK');

    $envPath = $appRoot . '/.env';
    if (!file_exists($envPath)) {
        log_message(".env file not found", 'ERROR');
        return false;
    }

    $env = file_get_contents($envPath);

    // Check key production settings
    $checks = [
        'APP_ENV=production' => strpos($env, 'APP_ENV=production') !== false,
        'APP_DEBUG=false' => strpos($env, 'APP_DEBUG=false') !== false,
        'HTTPS enabled' => strpos($env, 'SESSION_SECURE_COOKIE=true') !== false,
    ];

    $allPassed = true;
    foreach ($checks as $check => $result) {
        if ($result) {
            log_message("✓ $check", 'PASS');
        } else {
            log_message("✗ $check", 'FAIL');
            $allPassed = false;
        }
    }

    return $allPassed;
}

// Main deployment process
try {
    log_message("Starting deployment process");

    // Pull latest code (if using Git)
    if (is_dir($appRoot . '/.git')) {
        if (!run_command('git pull origin main')) {
            throw new Exception("Failed to pull latest code");
        }
    } else {
        log_message("Not a Git repository, skipping code update", 'WARN');
    }

    // Check environment
    if (!check_environment()) {
        log_message("Environment not properly configured for production", 'WARN');
        // Continue anyway, but with a warning
    }

    // Install/update dependencies
    log_message("Installing/updating Composer dependencies");
    if (!run_command('composer install --no-dev --optimize-autoloader')) {
        throw new Exception("Failed to install Composer dependencies");
    }

    // Build frontend assets
    log_message("Building frontend assets");
    if (!run_command('npm ci') || !run_command('npm run build')) {
        throw new Exception("Failed to build frontend assets");
    }

    // Run database migrations (with backup for safety)
    log_message("Backing up database and running migrations");
    $backupFile = 'storage/backups/pre_deploy_' . date('Y-m-d_H-i-s') . '.sql';

    // Create backup directory if it doesn't exist
    if (!is_dir($appRoot . '/storage/backups')) {
        mkdir($appRoot . '/storage/backups', 0755, true);
    }

    // Backup database using Laravel command if available
    if (file_exists($appRoot . '/artisan')) {
        run_command('php artisan db:backup ' . $backupFile);
    } else {
        log_message("Laravel backup command not available, skipping database backup", 'WARN');
    }

    // Run migrations
    if (!run_command('php artisan migrate --force')) {
        throw new Exception("Failed to run database migrations");
    }

    // Clear caches
    log_message("Clearing and optimizing caches");
    run_command('php artisan cache:clear');
    run_command('php artisan config:clear');
    run_command('php artisan route:clear');
    run_command('php artisan view:clear');

    // Optimize for production
    if (!run_command('php artisan config:cache') ||
        !run_command('php artisan route:cache') ||
        !run_command('php artisan view:cache')) {
        throw new Exception("Failed to optimize application caches");
    }

    // Set storage permissions
    log_message("Setting storage directory permissions");
    set_permissions($appRoot . '/storage', 0644, 0755);
    set_permissions($appRoot . '/storage/logs', 0644, 0775);
    set_permissions($appRoot . '/storage/framework', 0644, 0775);
    set_permissions($appRoot . '/bootstrap/cache', 0644, 0775);

    // Create symlink for storage if it doesn't exist
    if (!file_exists($appRoot . '/public/storage')) {
        log_message("Creating storage symlink");
        run_command('php artisan storage:link');
    }

    // Final optimizations
    log_message("Running final optimizations");
    run_command('php artisan optimize');

    $duration = round(microtime(true) - $startTime, 2);
    log_message("Deployment completed successfully in $duration seconds");

    // Run a test to make sure the site is responding
    log_message("Testing application health...");

    // Get the APP_URL from .env
    preg_match('/APP_URL=(.*)/', file_get_contents($appRoot . '/.env'), $matches);
    $appUrl = isset($matches[1]) ? trim($matches[1]) : 'http://localhost';

    // Make a simple request to the homepage
    $ch = curl_init($appUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if ($httpCode >= 200 && $httpCode < 300 && $response) {
        log_message("Health check passed: HTTP $httpCode");
    } else {
        log_message("Health check failed: HTTP $httpCode", 'WARN');
    }

    curl_close($ch);

} catch (Exception $e) {
    log_message("Deployment failed: " . $e->getMessage(), 'ERROR');
    exit(1);
}
